(function ($, Drupal, drupalSettings) {
  Drupal.behaviors.sfc_bk_status_messages = {
    attach: function attach(context, settings) {
      $(once('sfcAttach', $("[data-sfc-id=\"bk_status_messages\"]", context).addBack("[data-sfc-id=\"bk_status_messages\"]"))).each(function () {

  $(this).find('.bk-status-messages__dismiss').on('click', function () {
    $(this).parent().fadeOut(300, function () {
      $(this).remove();
    });
  });

      });
    },
    detach: function detach(context, settings, trigger) {
      var element = $("[data-sfc-id=\"bk_status_messages\"]", context).addBack("[data-sfc-id=\"bk_status_messages\"]");once.remove('sfcAttach', element);once.remove('sfcDetach', element);
    },
  }
})(jQuery, Drupal, drupalSettings);
